/** @type {import('next').NextConfig} */
const nextConfig = {
    devIndicators: false
  };
   module.exports = nextConfig;
 