"use client";

import Loader from "@/components/shared/loader";

export default function DashboardLoading() {
  return <Loader />;
}
